import math

class StationManager:
    def __init__(self, stations, radius):
        self.stations = stations
        self.radius = radius
        self.detections = {name: set() for name in stations}
        self.current_count = 0
        self.current_train_count = 0

    def check_detections(self, moving_objects):
        for name in self.detections:
            self.detections[name].clear()

        for obj in moving_objects:
            for station_name, (sx, sy) in self.stations.items():
                if self.is_within_radius(obj.x, obj.y, sx, sy):
                    self.detections[station_name].add(obj.name)

    def is_within_radius(self, x1, y1, x2, y2):
        return math.hypot(x1 - x2, y1 - y2) <= self.radius

    def get_status_lines(self):
        lines = []
        for station_name, objects in self.detections.items():
            if objects:
                objs = ', '.join(sorted(objects))
                lines.append(f"{station_name} 📡 {objs}")
            else:
                lines.append(f"{station_name} 📡 (No detections)")
        lines.append(f"Live People Count - Platform: {self.current_count}")
        lines.append(f"Live People Count - Train: {self.current_train_count}")
        return lines

    def get_station_info(self, station_name):
        apps, buses, trains = [], [], []
        for obj_name in self.detections.get(station_name, []):
            if obj_name.startswith("App"):
                apps.append(obj_name)
            elif obj_name.startswith("Bus"):
                buses.append(obj_name)
            elif obj_name.startswith("Train"):
                trains.append(obj_name)
        return apps, buses, trains

    def updatePeopleCount(self, count):
        self.current_count = count
        print(f"[StationManager] Platform people count updated: {count}")

    def updateTrainCount(self, count):
        self.current_train_count = count
        print(f"[StationManager] Train people count updated: {count}")
