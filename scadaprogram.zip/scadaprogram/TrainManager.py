
from VehicleManager import VehicleManager


class TrainManager(VehicleManager):
    def __init__(self, canvas, stations):
        super().__init__(canvas)
        self.station_positions = list(stations.values())
        self.create_trains()

    def create_trains(self):
        for i, (x, y) in enumerate(self.station_positions[:2]):
            route = self.station_positions[i:] + [self.station_positions[0]]
            self.create_vehicle(
                name=f"Train {i + 1}",
                x=x,
                y=y,
                speed=2,
                color="gray" if i % 2 == 0 else "pink",
                route=route,
                pause_stations=self.station_positions
            )
