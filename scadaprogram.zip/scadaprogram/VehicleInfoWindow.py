import tkinter as tk


class VehicleInfoWindow:
    def __init__(self, vehicle, title=None):
        self.vehicle = vehicle
        self.window = tk.Toplevel()
        self.window.title(title or f"{vehicle.name} Info")
        self.window.geometry("250x150")

        self.label = tk.Label(self.window, text="", font=("Consolas", 12))
        self.label.pack(padx=10, pady=10)

        self.passenger_label = tk.Label(self.window, text="Passengers: None", font=("Consolas", 10))
        self.passenger_label.pack(padx=10, pady=5)

        self.close_btn = tk.Button(self.window, text="Close", command=self.window.destroy)
        self.close_btn.pack(pady=5)

        self.update_coords()

    def update_coords(self):
        if self.window.winfo_exists():
            x = int(self.vehicle.x)
            y = int(self.vehicle.y)
            passengers = ", ".join(self.vehicle.passengers) if self.vehicle.passengers else "None"
            self.label.config(text=f"{self.vehicle.name}\nX: {x}\nY: {y}")
            self.passenger_label.config(text=f"Passengers: {passengers}")
            self.window.after(200, self.update_coords)