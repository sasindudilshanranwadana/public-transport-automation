
from MovingObject import MovingObject

from VehicleInfoWindow import VehicleInfoWindow


class VehicleManager:
    def __init__(self, canvas):
        self.vehicles = []
        self.canvas = canvas

    def create_vehicle(self, name, x, y, speed, color, route, pause_stations):
        vehicle = MovingObject(name, x, y, speed=speed, canvas=self.canvas, color=color)
        vehicle.set_route(route, is_fixed_route=True)
        vehicle.set_pause_stations(pause_stations)
        self.vehicles.append(vehicle)
        self.canvas.tag_bind(vehicle.canvas_id, "<Button-1>", lambda event, v=vehicle: self.on_click(event, v))

    def on_click(self, event, vehicle):
        if hasattr(self, 'info_window') and self.info_window and self.info_window.window.winfo_exists():
            self.info_window.window.lift()
        else:
            self.info_window = VehicleInfoWindow(vehicle)